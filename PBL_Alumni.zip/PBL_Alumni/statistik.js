document.addEventListener('DOMContentLoaded', function() {
    let alumniList = JSON.parse(localStorage.getItem('alumniList')) || [];
    
    // Example data preparation
    let genderCounts = { 'Laki-Laki': 0, 'Perempuan': 0 };
    let yearCounts = {};
    let bloodTypeCounts = { 'A': 0, 'AB': 0, 'B': 0, 'O': 0 };
    let jobCounts = { 'Software engineer': 0, 'Web developer': 0, 'Computer network architect': 0, 'Database administrator': 0, 'Computer programmer': 0 };

    alumniList.forEach(alumni => {
        genderCounts[alumni.gender === 'male' ? 'Laki-Laki' : 'Perempuan']++;
        yearCounts[alumni.thnLulus] = (yearCounts[alumni.thnLulus] || 0) + 1;
        bloodTypeCounts[alumni.goldar]++;
        jobCounts[alumni.pekerjaan]++;
    });

    // Create charts
    var ctxGender = document.getElementById('genderChart').getContext('2d');
    var chartGender = new Chart(ctxGender, {
        type: 'pie',
        data: {
            labels: Object.keys(genderCounts),
            datasets: [{
                data: Object.values(genderCounts),
                backgroundColor: ['#FF6384', '#36A2EB']
            }]
        }
    });

    var ctxYear = document.getElementById('yearChart').getContext('2d');
    var chartYear = new Chart(ctxYear, {
        type: 'bar',
        data: {
            labels: Object.keys(yearCounts),
            datasets: [{
                label: 'Jumlah Alumni per Tahun Lulus',
                data: Object.values(yearCounts),
                backgroundColor: '#FFCE56'
            }]
        }
    });

    var ctxBlood = document.getElementById('bloodTypeChart').getContext('2d');
    var chartBlood = new Chart(ctxBlood, {
        type: 'doughnut',
        data: {
            labels: Object.keys(bloodTypeCounts),
            datasets: [{
                data: Object.values(bloodTypeCounts),
                backgroundColor: ['#E7E9ED', '#C6E2FF', '#A8D5E2', '#88C6E0']
            }]
        }
    });

    var ctxJob = document.getElementById('jobChart').getContext('2d');
    var chartJob = new Chart(ctxJob, {
        type: 'bar',
        data: {
            labels: Object.keys(jobCounts),
            datasets: [{
                label: 'Jumlah Alumni per Bidang Pekerjaan',
                data: Object.values(jobCounts),
                backgroundColor: '#FF99CC'
            }]
        }
    });
});