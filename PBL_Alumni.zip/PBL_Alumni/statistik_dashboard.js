// file : dashboard_alumni.html
// Pie chart data
const pieChartData = {
    labels: ['Software engineer', 'Web developer', 'Database administrator', 'Computer network architect', 'Computer programmer'],
    datasets: [{
    data: [7242, 4563, 1345, 946, 2150],
    backgroundColor: [
        'rgba(100, 149, 237, 1)',
        'rgba(107, 142, 35, 1)',
        'rgba(255, 165, 0, 1)',
        'rgba(255, 99, 71, 1)',
        'rgba(220, 20, 60, 1)'
    ],
    borderColor: [
        'rgba(100, 149, 237, 1)',
        'rgba(107, 142, 35, 1)',
        'rgba(255, 165, 0, 1)',
        'rgba(255, 99, 71, 1)',
        'rgba(220, 20, 60, 1)'
    ],
    borderWidth: 1
    }]
};

// Bar chart data
const barChartData = {
    labels: ['2019', '2020', '2021', '2022', '2023', '2024', '2025'],
    datasets: [{
    label: 'Laki-laki',
    data: [4.0, 3.0, 2.5, 1.5, 3.5, 3.0, 2.8],
    backgroundColor: 'rgba(100, 149, 237, 1)',
    borderColor: 'rgba(100, 149, 237, 1)',
    borderWidth: 1
    }, {
    label: 'Perempuan',
    data: [2.0, 2.5, 2.0, 3.0, 1.0, 2.5, 1.5],
    backgroundColor: 'rgba(255, 99, 71, 1)',
    borderColor: 'rgba(255, 99, 71, 1)',
    borderWidth: 1
    }]
};

// // Create the pie chart
// const pieChartCanvas = document.getElementById('pieChart');
// const pieChart = new Chart(pieChartCanvas, {
//     type: 'pie',
//     data: pieChartData
// });

// // Create the bar chart
// const barChartCanvas = document.getElementById('barChart');
// const barChart = new Chart(barChartCanvas, {
//     type: 'bar',
//     data: barChartData,
//     options: {
//     scales: {
//         y: {
//         beginAtZero: true
//         }
//     }
//     }
// });

