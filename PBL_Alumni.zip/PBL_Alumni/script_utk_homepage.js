// File : login_utk_homepage.html
//// User Data (Can be stored in local storage)
let users = []; // Array to store user data

// Load User data from local Storage user data
function loadUsers() {
    const storedUsers = localStorage.getItem('users');
    if (storedUsers) {
        users = JSON.parse(storedUsers);
    }
}

// Save User Data to Local Storage
function saveUsers(){
    localStorage.setItem('users', JSON.stringify(users));
}

function loginUser() {
    const usernameOrEmail = document.getElementById('username_or_email').value;
    const password = document.getElementById('password').value;

    const user = users.find(u => (u.username === usernameOrEmail || u.email === usernameOrEmail) && u.password === password);

    if (user) {
        // Login successful
        // 1. Save login status in local storage (if checkbox is checked)
        if (document.getElementById('remember_password').checked) {
            localStorage.setItem('isLoggedIn', true);
            localStorage.setItem('currentUser', JSON.stringify(user));
        }
        // 2. Redirect to homepage (index_utama.html)
        alert('Login berhasil!');
        window.location.href = 'homepage.html';
    } else {
        // Invalid credentials
        alert('Username atau password salah');
    }
}

function signupUser() {
    const namaLengkap = document.getElementById('nama_lengkap_id').value;
    const usernameOrEmail = document.getElementById('username_or_email_id').value;
    const password = document.getElementById('password_id').value;
    const confirmPassword = document.getElementById('confirm_password_id').value;

    if (password !== confirmPassword) {
        alert('Password and confirm password do not match!');
        return;
    }

    const newUser = {
        namaLengkap: namaLengkap,
        username: usernameOrEmail,
        email: usernameOrEmail, // You can have separate email field if needed
        password: password
    };
  
    // Check if the username or email already exists
    if (users.some(user => user.username === usernameOrEmail || user.email === usernameOrEmail)) {
        alert('Username or Email already exists!');
        return;
    }
  
    users.push(newUser); 
    saveUsers();
    alert('Registrasi berhasil! - Silakan login di sini...');
    window.location.href = 'login.html';
}

loadUsers();

// Fungsi untuk menampilkan semua user terdaftar dalam format tabel
function displayRegisteredUsers() {
    loadUsers(); // Load user data from local storage
    const userTable = document.getElementById('userTable');

    userTable.innerHTML = '';

    // Membuat header tabel
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = '<th>Nama Lengkap</th><th>Username</th><th>Email</th><th>Password</th><th>Aksi</th>';
    userTable.appendChild(headerRow);

    users.forEach(function(user) {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${user.namaLengkap}</td>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td>${user.password}</td>
            <td>
                <button class="edit" onclick="editUser('${user.username}')">Edit</button> | 
                <button class="delete" onclick="deleteUser('${user.username}')">Hapus</button>
            </td>
        `;
        userTable.appendChild(row);
    });
}

// Fungsi untuk menghapus user dari local storage
function deleteUser(username) {
    if (confirm(`Apakah Anda yakin ingin menghapus user ${username}?`)) {
        loadUsers(); // Load user data from local storage
        const index = users.findIndex(user => user.username === username);
        if (index!== -1) {
            users.splice(index, 1);
            saveUsers(); // Save user data to local storage
        }
        displayRegisteredUsers(); // Refresh daftar user setelah penghapusan
    }
}

// Fungsi untuk mengedit user di local storage
function editUser(username) {
    loadUsers(); // Load user data from local storage
    const index = users.findIndex(user => user.username === username);
    if (index!== -1) {
        const user = users[index];
        const newNamaLengkap = prompt(`Masukkan nama lengkap baru untuk user ${username}:`);
        const newEmail = prompt(`Masukkan email baru untuk user ${username}:`);
        const newPassword = prompt(`Masukkan password baru untuk user ${username}:`);

        if (newNamaLengkap) {
            user.namaLengkap = newNamaLengkap;
        }
        if (newEmail) {
            user.email = newEmail;
        }
        if (newPassword) {
            user.password = newPassword;
        }

        saveUsers(); // Save user data to local storage
        displayRegisteredUsers(); // Refresh daftar user setelah pengeditan
    }
}